from django.apps import AppConfig


class DashboardAppConfig(AppConfig):
    name = 'dashboard_app'
